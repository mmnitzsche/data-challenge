#case 2
imdb_query = """SELECT * FROM IMDB_movies"""

