SELECT product_cod, product_name,product_val FROM `looqbox-challenge`.data_product order by product_val desc limit 10ff
